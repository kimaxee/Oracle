-- 실습 3-1
ALTER USER SCOTT
IDENTIFIED BY tiger
ACCOUNT UNLOCK;

-- 실습 3-2
CONN scott/tiger;

-- 실습 3-3
DESC EMP;

-- 실습 3-4
EXIT

-- 실습 3-5
SQLPLUS scott/tiger

